// wallHack.h.js

class WallHack
{
    process = null; // args: 1 - localPlayer
}