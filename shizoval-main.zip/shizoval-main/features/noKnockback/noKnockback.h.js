// noKnockback.h.js

class NoKnockback
{
    init = null; // args: 1 - localPlayer
}