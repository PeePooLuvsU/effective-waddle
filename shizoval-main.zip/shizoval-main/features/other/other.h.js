// other.h.js

class Other
{
    process = null; // args: 1 - localPlayer
}