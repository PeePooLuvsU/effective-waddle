// boxTeleport.h.js

class BoxTeleport
{
    process = null; // args: 1 - localPlayer
}