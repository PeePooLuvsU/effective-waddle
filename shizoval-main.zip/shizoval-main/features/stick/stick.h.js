// stick.h.js

class Stick
{
    process = null; // args: 1 - localPlayer
}