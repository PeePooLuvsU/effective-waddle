// clicker.h.js

class Clicker
{
    process = null; // args: 1 - localPlayer
}