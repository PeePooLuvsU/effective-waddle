// sync.h.js

class Sync
{
    init = null; // args: 1 - localPlayer
}