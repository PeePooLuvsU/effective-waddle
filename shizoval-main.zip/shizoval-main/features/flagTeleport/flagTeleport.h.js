// flagTeleport.h.js

class FlagTeleport 
{
    process = null; // args: 1 - localPlayer
}