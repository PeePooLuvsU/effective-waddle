// airBreak.h.js

class AirBreak
{
    process = null; // args: 1 - localPlayer
}