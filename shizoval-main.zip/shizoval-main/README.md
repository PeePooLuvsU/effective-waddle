# shizoval
Free open-source game cheat for Tanki Online.

**солевой#4769**

<details>
<summary>Русский</summary>
  
## Установка

**1.** Установите [Tampermonkey](https://www.tampermonkey.net/)

**2.** Установите [скрипт](https://raw.githubusercontent.com/sheezzmee/shizoval/main/shizoval.user.js)

## Клавиши

`INSERT` - Открыть меню

`SHIFT` (правый) - включить/отключить полет

`J` - пока нажата клавиша, отключает функции, которые вызывает краши при большом пинге

</details>

<details>
<summary>English</summary>
  
## Getting started

**1.** Install [Tampermonkey](https://www.tampermonkey.net/)

**2.** Install [script](https://raw.githubusercontent.com/sheezzmee/shizoval/main/shizoval.user.js)

## Binds

`INSERT` - Open cheat menu

`SHIFT` (right) - toggle AirBreak

`J` - ping key (while the key is pressed: disables functions that cause crashes on high ping)
  
</details>
