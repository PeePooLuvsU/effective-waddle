// cheatMenu.c.js

class CheatMenu
{
    draw = null; // args: 1 - time
}

class Tabs
{
    localPlayer = null; // args: void
    weapon = null; // args: void
    visuals = null; // args: void
    players = null; // args: void
}